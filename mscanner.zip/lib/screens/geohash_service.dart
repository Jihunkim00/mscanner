import 'package:dart_geohash/dart_geohash.dart';

class GeohashService {
  static const String _base32 = '0123456789bcdefghjkmnpqrstuvwxyz';
  static const List<int> _bits = [16, 8, 4, 2, 1];

  final GeoHasher _geoHasher = GeoHasher();

  /// 너가 구현한 geohash 생성 방식 유지
  String generateGeohash(double latitude, double longitude, {int precision = 8}) {
    final latInterval = [-90.0, 90.0];
    final lonInterval = [-180.0, 180.0];
    final hash = StringBuffer();
    bool isEven = true;
    int bit = 0;
    int ch = 0;

    while (hash.length < precision) {
      double mid;
      if (isEven) {
        mid = (lonInterval[0] + lonInterval[1]) / 2;
        if (longitude > mid) {
          ch |= _bits[bit];
          lonInterval[0] = mid;
        } else {
          lonInterval[1] = mid;
        }
      } else {
        mid = (latInterval[0] + latInterval[1]) / 2;
        if (latitude > mid) {
          ch |= _bits[bit];
          latInterval[0] = mid;
        } else {
          latInterval[1] = mid;
        }
      }

      isEven = !isEven;
      if (bit < 4) {
        bit++;
      } else {
        hash.write(_base32[ch]);
        bit = 0;
        ch = 0;
      }
    }

    return hash.toString();
  }

  /// 정확한 이웃 geohash 8개 + center hash 총 9개 반환 (RAG 전용)
  List<String> getNeighborGeohashes(String centerHash) {
    final neighborsMap = _geoHasher.neighbors(centerHash); // Map<String, String>
    final neighbors = neighborsMap.values.toList();
    return [centerHash, ...neighbors];
  }
}

import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:getwidget/getwidget.dart';
import 'package:mscanner/l10n/gen_l10n/app_localizations.dart';
import '/screens/Login_Screen.dart';

class IntroductionScreenPage extends StatefulWidget {
  @override
  _IntroductionScreenPageState createState() => _IntroductionScreenPageState();
}

class _IntroductionScreenPageState extends State<IntroductionScreenPage> {
  Timer? _timer;
  bool _isIntroCompleted = false; // 네비게이션 중복 방지 플래그

  @override
  void initState() {
    super.initState();
    print('IntroductionScreenPage: initState - starting 20-second timer');
    _timer = Timer(Duration(seconds: 20), _completeIntro);
  }

  @override
  void dispose() {
    print('IntroductionScreenPage: dispose - cancelling timer');
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _completeIntro() async {
    if (_isIntroCompleted) {
      print('IntroductionScreenPage: Intro already completed');
      return;
    }
    _isIntroCompleted = true;
    print('IntroductionScreenPage: Completing intro and navigating to LoginScreen');

    // 네비게이션 전에 현재 context가 여전히 유효한지 확인
    if (!mounted) {
      print('IntroductionScreenPage: Context not mounted. Aborting navigation.');
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context).size;
    final localizations = AppLocalizations.of(context);

    return Scaffold(
      body: Stack(
        children: [
          // 배경 이미지
          GFImageOverlay(
            height: mediaQuery.height,
            width: mediaQuery.width,
            image: AssetImage(
              Platform.isIOS
                  ? 'assets/images/apple_sample.png'
                  : 'assets/images/android_sample.png',
            ),
            boxFit: BoxFit.cover,
          ),
          // 인트로 텍스트
          Positioned(
            top: mediaQuery.height * 0.15,
            left: 20,
            right: 20,
            child: Text(
              localizations?.languagesdescprition ?? 'Welcome to the App!',
              style: TextStyle(
                fontFamily: 'SF Pro Display',
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          // 추가 텍스트 또는 이미지 (필요에 따라 조정)
          Positioned(
            top: mediaQuery.height * 0.9,
            left: 20,
            right: 20,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Semantics(
                  label: '${localizations?.introductionTitle1 ?? 'Introduction Title'} ${localizations?.languagesdescprition1 ?? ''}',
                  child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: localizations?.introductionTitle1 ?? 'Introduction Title',
                          style: TextStyle(
                            fontFamily: 'SF Pro Display',
                            fontSize: 36,
                            fontWeight: FontWeight.bold,
                            color: Colors.white54,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          // "Skip" 버튼
          Positioned(
            right: 20,
            bottom: 30,
            child: GFButton(
              onPressed: _completeIntro,
              text: localizations?.skip ?? 'Skip',
              color: Colors.transparent,
              textStyle: TextStyle(
                fontFamily: 'SF Pro Display',
                color: Colors.white54,
                fontSize: 16,
              ),
              type: GFButtonType.transparent,
              highlightColor: Colors.transparent,
              splashColor: Colors.transparent,
            ),
          ),
        ],
      ),
    );
  }
}

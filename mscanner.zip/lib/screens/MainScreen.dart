import 'package:flutter/material.dart';

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Main Screen'),
        backgroundColor: Colors.blueGrey, // AppBar 배경색 설정
        actions: [
          IconButton(
            icon: Icon(Icons.settings, size: 30.0), // 아이콘 크기 설정
            onPressed: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),
          IconButton(
            icon: Icon(Icons.history, size: 30.0), // 아이콘 크기 설정
            onPressed: () {
              Navigator.pushNamed(context, '/history');
            },
          ),
          IconButton(
            icon: Icon(Icons.insert_chart, size: 30.0), // 아이콘 크기 설정
            onPressed: () {
              Navigator.pushNamed(context, '/result');
            },
          ),
        ],
      ),
      body: Center(
        child: Text('Main Screen'),
      ),
    );
  }
}

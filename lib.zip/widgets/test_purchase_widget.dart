import 'dart:async';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mscanner/l10n/gen_l10n/app_localizations.dart';

class TestPurchaseWidget extends StatefulWidget {
  const TestPurchaseWidget({super.key});

  @override
  State<TestPurchaseWidget> createState() => _TestPurchaseWidgetState();
}

class _TestPurchaseWidgetState extends State<TestPurchaseWidget> {
  final InAppPurchase _iap = InAppPurchase.instance;
  late final StreamSubscription<List<PurchaseDetails>> _sub;
  List<ProductDetails> _products = [];
  bool _loading = true;
  String? _error;
  bool _isPremium = false;

  static const _productIds = <String>{ 'remove_ads_week_trial' };

  @override
  void initState() {
    super.initState();
    _sub = _iap.purchaseStream.listen(
      _onPurchaseUpdated,
      onError: _onPurchaseError,
      onDone: () => _sub.cancel(),
    );
    _initialize();
  }

  Future<void> _initialize() async {
    final available = await _iap.isAvailable();
    if (!available) {
      setState(() {
        _error = AppLocalizations.of(context)!.iapUnavailable;
        _loading = false;
      });
      return;
    }

    final response = await _iap.queryProductDetails(_productIds);
    if (response.error != null) {
      setState(() {
        _error = response.error!.message;
        _loading = false;
      });
      return;
    }

    setState(() {
      _products = response.productDetails;
      _loading = false;
    });

    // 사용자가 이미 구매했는지 확인 (비소모성)
    _checkPreviousPurchase();
  }

  Future<void> _checkPreviousPurchase() async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final doc = await FirebaseFirestore.instance
        .collection('user_points')
        .doc(uid)
        .get();

    if (doc.exists && doc.data()?['userStatus'] == 'premium') {
      setState(() {
        _isPremium = true;
      });
    }
  }

  void _onPurchaseUpdated(List<PurchaseDetails> purchases) {
    for (var purchase in purchases) {
      if (purchase.status == PurchaseStatus.purchased) {
        _onPurchaseSuccess(purchase);
        if (purchase.pendingCompletePurchase) {
          _iap.completePurchase(purchase);
        }
        debugPrint('✅ 결제 완료: ${purchase.productID}');
      } else if (purchase.status == PurchaseStatus.error) {
        debugPrint('❌ 결제 오류: ${purchase.error}');
      }
    }
  }

  Future<void> _onPurchaseSuccess(PurchaseDetails purchase) async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final userPointRef = FirebaseFirestore.instance
        .collection('user_point')
        .doc(uid);

    await userPointRef.set({
      'userStatus': 'premium',
      'purchaseTime': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    setState(() {
      _isPremium = true;
    });
  }

  void _onPurchaseError(Object error) {
    debugPrint('💥 purchaseStream error: $error');
  }

  void _buy(ProductDetails product) {
    final param = PurchaseParam(productDetails: product);
    _iap.buyNonConsumable(purchaseParam: param);
  }

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return ListTile(title: Text(_error!));
    }
    if (_products.isEmpty) {
      return ListTile(title: Text(AppLocalizations.of(context)!.noAvailableProducts));
    }
    if (_isPremium) {
      return ListTile(
        leading: const Icon(Icons.check),
        title: Text(AppLocalizations.of(context)!.premiumUserTitle),
        subtitle: Text(AppLocalizations.of(context)!.premiumUserSubtitle),
      );
    }
    final product = _products.first;
    return ListTile(
      leading: const Icon(Icons.star),
      title: Text(product.title),
      subtitle: Text(product.description),
      trailing: ElevatedButton(
        onPressed: () => _buy(product),
        child: Text(product.price),
      ),
    );
  }
}

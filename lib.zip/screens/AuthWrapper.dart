import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '/screens/Home_Screen.dart';
import '/screens/Login_Screen.dart';
import '/screens/introduction_screen_page.dart';

class AuthWrapper extends StatelessWidget {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<bool> _hasUserData(String uid) async {
    try {
      DocumentSnapshot doc = await _firestore.collection('users').doc(uid).get();
      print('Firestore user data exists: ${doc.exists} for uid: $uid');
      return doc.exists;
    } catch (e) {
      print('Error fetching user data: $e');
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        // 로딩 상태
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        // 사용자가 로그인한 상태
        if (snapshot.hasData && snapshot.data != null) {
          print('AuthWrapper: User is logged in: ${snapshot.data!.uid}');
          return FutureBuilder<bool>(
            future: _hasUserData(snapshot.data!.uid),
            builder: (context, userSnapshot) {
              if (userSnapshot.connectionState == ConnectionState.waiting) {
                return Scaffold(
                  body: Center(child: CircularProgressIndicator()),
                );
              }

              if (userSnapshot.hasData && userSnapshot.data == true) {
                print('AuthWrapper: Navigating to HomeScreen');
                return HomeScreen();
              } else {
                print('AuthWrapper: Navigating to IntroductionScreenPage');
                return IntroductionScreenPage();
              }
            },
          );
        }

        // 사용자가 로그인하지 않은 상태
        print('AuthWrapper: User is not logged in. Navigating to IntroductionScreenPage');
        return IntroductionScreenPage();
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'Loading_Screen.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'package:mscanner/l10n/gen_l10n/app_localizations.dart';


class CameraScreen extends StatefulWidget {
  final VoidCallback onCancel;

  CameraScreen({required this.onCancel});

  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  final picker = ImagePicker();

  String _response = '';
  Position? _position;
  DateTime? _captureTime;

  @override
  void initState() {
    super.initState();
    _pickImage(); // 화면이 시작되면 바로 카메라 실행
  }

  bool _isProcessing = false;

  Future<void> _pickImage() async {
    if (_isProcessing) return;
    _isProcessing = true;

    try {
      final pickedFile = await picker.pickImage(source: ImageSource.camera);

      if (pickedFile == null) {
        widget.onCancel(); // 카메라 취소
        _isProcessing = false;
        return;
      }

      File tempFile = File(pickedFile.path);
      if (!await tempFile.exists()) {
        widget.onCancel(); // 파일 없음
        _isProcessing = false;
        return;
      }

      _captureTime = DateTime.now(); // 사진 찍은 시간 저장

      // 이미지 압축
      File compressedFile = await compressImage(tempFile);


      // 현재 위치 가져오기
      // 위치도 기다리며 받아오기
      Position? position = await _getCurrentLocation();

// setState 없이 바로 화면 전환
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => LoadingScreen(
            image: compressedFile, // ✅ 직접 전달, _image 변수 필요 없음
            captureTime: _captureTime!,
            position: position,
          ),
        ),
      );


    } catch (e) {
      print("이미지 처리 중 오류: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(AppLocalizations.of(context)?.loadingError ?? "분석 중 오류가 발생했습니다.")),
        );
      }
      widget.onCancel();
    } finally {
      _isProcessing = false;
    }
  }


  Future<File> compressImage(File file) async {
    final tempDir = await getTemporaryDirectory();
    final targetPath =
        '${tempDir.path}/compressed_${DateTime.now().millisecondsSinceEpoch}.jpg';

    var result = await FlutterImageCompress.compressAndGetFile(
      file.absolute.path,
      targetPath,
      minHeight: 1920,
      minWidth: 1080,
      quality: 50,
    );

    if (result != null) {
      return File(result.path); // XFile을 File로 변환
    } else {
      throw Exception('Failed to compress image');
    }
  }



  Future<Position?> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _showLocationServiceDialog();
      return null;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        _showLocationPermissionDialog();
        return null;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      _showLocationPermissionDialog();
      return null;
    }

    return await Geolocator.getCurrentPosition(); // ✅ Position을 반환함
  }


  void _showLocationPermissionDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        if (Platform.isIOS) {
          return CupertinoAlertDialog(
            title: Text(
                AppLocalizations.of(context)!.locationPermissionNeeded), // 로컬라이즈된 제목
            content: Text(AppLocalizations.of(context)!
                .locationPermissionContent), // 로컬라이즈된 내용
            actions: [
              CupertinoDialogAction(
                child: Text(AppLocalizations.of(context)!.cancel), // 로컬라이즈된 "취소" 버튼
                onPressed: () {
                  Navigator.of(context).pop();
                  widget.onCancel();
                },
              ),
              CupertinoDialogAction(
                child:
                Text(AppLocalizations.of(context)!.openSettings), // 로컬라이즈된 "설정 열기" 버튼
                onPressed: () {
                  Navigator.of(context).pop();
                  Geolocator.openAppSettings();
                },
              ),
            ],
          );
        } else {
          return AlertDialog(
            title: Text(
                AppLocalizations.of(context)!.locationPermissionNeeded), // 로컬라이즈된 제목
            content: Text(AppLocalizations.of(context)!
                .locationPermissionContent), // 로컬라이즈된 내용
            actions: [
              TextButton(
                child: Text(AppLocalizations.of(context)!.cancel), // 로컬라이즈된 "취소" 버튼
                onPressed: () {
                  Navigator.of(context).pop();
                  widget.onCancel();
                },
              ),
              TextButton(
                child:
                Text(AppLocalizations.of(context)!.openSettings), // 로컬라이즈된 "설정 열기" 버튼
                onPressed: () {
                  Navigator.of(context).pop();
                  Geolocator.openAppSettings();
                },
              ),
            ],
          );
        }
      },
    );
  }

  void _showLocationServiceDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        if (Platform.isIOS) {
          return CupertinoAlertDialog(
            title: Text(
                AppLocalizations.of(context)!.locationServiceDisabled), // 로컬라이즈된 제목
            content: Text(AppLocalizations.of(context)!
                .locationServiceDisabledContent), // 로컬라이즈된 내용
            actions: [
              CupertinoDialogAction(
                child: Text(AppLocalizations.of(context)!.cancel), // 로컬라이즈된 "취소" 버튼
                onPressed: () {
                  Navigator.of(context).pop();
                  widget.onCancel();
                },
              ),
              CupertinoDialogAction(
                child:
                Text(AppLocalizations.of(context)!.openSettings), // 로컬라이즈된 "설정 열기" 버튼
                onPressed: () {
                  Navigator.of(context).pop();
                  Geolocator.openLocationSettings();
                },
              ),
            ],
          );
        } else {
          return AlertDialog(
            title: Text(
                AppLocalizations.of(context)!.locationServiceDisabled), // 로컬라이즈된 제목
            content: Text(AppLocalizations.of(context)!
                .locationServiceDisabledContent), // 로컬라이즈된 내용
            actions: [
              TextButton(
                child: Text(AppLocalizations.of(context)!.cancel), // 로컬라이즈된 "취소" 버튼
                onPressed: () {
                  Navigator.of(context).pop();
                  widget.onCancel();
                },
              ),
              TextButton(
                child:
                Text(AppLocalizations.of(context)!.openSettings), // 로컬라이즈된 "설정 열기" 버튼
                onPressed: () {
                  Navigator.of(context).pop();
                  Geolocator.openLocationSettings();
                },
              ),
            ],
          );
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return WillPopScope(
      onWillPop: () async => false, // 뒤로 가기 버튼 비활성화
      child: Scaffold(
        backgroundColor:
        isDarkMode ? Colors.black : Color(0xFFEFEFF4), // 배경색 설정
        appBar: AppBar(
          backgroundColor:
          isDarkMode ? Colors.black : Color(0xFFEFEFF4), // AppBar 배경색 설정
          foregroundColor:
          isDarkMode ? Colors.white : Colors.black, // AppBar 텍스트 색상 설정
          title: null, // title 텍스트 제거
          leading: SizedBox.shrink(), // 빈 공간으로 대체하여 뒤로 가기 버튼 숨기기
        ),
        body: Center(
          child: CupertinoActivityIndicator(radius: 15), // 또는 SizedBox.shrink()
        ),
      ),
    );
  }
}

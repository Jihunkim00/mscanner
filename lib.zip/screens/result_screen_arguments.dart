// lib/screens/result_screen_arguments.dart

import 'dart:io';
import 'package:geolocator/geolocator.dart';

class ResultScreenArguments {
  final File image;
  final String response;
  final Position? position;
  final DateTime captureTime;
  final bool isFromHistory;
  final String? title;
  final String? location;
  final String? geohash;
  final String? ragDetail;

  ResultScreenArguments({
    required this.image,
    required this.response,
    this.position,
    required this.captureTime,
    this.isFromHistory = false,
    this.title,
    this.location,
    this.geohash,
    this.ragDetail,
  });
}
